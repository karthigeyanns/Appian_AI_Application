const axe = require("axe-core");

const checkAccessibility = async (html) => {
  const results = await axe.run(html);
  return results.violations;
};
