const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();

// Middleware
app.use(bodyParser.json());
app.use(cors()); // Allow requests from different origins

// Endpoint for HTML optimization
app.post("/optimize-html", (req, res) => {
  const { html } = req.body;

  if (!html) {
    return res.status(400).json({ error: "HTML content is required." });
  }

  // Example: Simple optimization
  let optimizedHTML = html.replace(
    "<body>",
    "<body>\n<meta charset='UTF-8'>\n<meta name='viewport' content='width=device-width, initial-scale=1.0'>"
  );

  optimizedHTML = optimizedHTML.replace(
    /<div>(.*?)<\/div>/g,
    (_, content) => `<section>${content}</section>`
  );

  res.json({ optimizedHTML });
});

// Start the server
const PORT = 3001;
app.listen(PORT, () => {
  console.log(`Backend server is running on http://localhost:${8080}`);
});
