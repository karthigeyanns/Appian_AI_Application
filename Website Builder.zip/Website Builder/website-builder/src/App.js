import React from "react";
import Editor from "./components/Editor";
import './App.css';


function App() {
  return (
    <div className="App">
      <header>
        <h1>Website Builder Application</h1>
      </header>
      <main>
        <Editor />
      </main>
    </div>
  );
}

export default App;
