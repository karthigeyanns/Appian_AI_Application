import React from "react";

const DragItem = ({ content }) => {
  const handleDragStart = (e) => {
    e.dataTransfer.setData("text/plain", content);
  };

  return (
    <div
      className="drag-item"
      draggable
      onDragStart={handleDragStart}
    >
      {content}
    </div>
  );
};

export default DragItem;
