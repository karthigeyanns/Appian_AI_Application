import React, { useState } from "react";
import DragItem from "./DragItem";
import DropZone from "./DropZone";
import Preview from "./Preview";
import { optimizeHTML } from "../api/optimizeHtml";


const Editor = () => {
  const [layout, setLayout] = useState([]);
  const [optimizedHTML, setOptimizedHTML] = useState("");

  const addComponent = (component) => {
    setLayout([...layout, component]);
  };

  const handleOptimize = async () => {
    const html = layout
      .map((comp) => `<div>${comp.content}</div>`)
      .join("\n");

    try {
      const { optimizedHTML } = await optimizeHTML(html);
      setOptimizedHTML(optimizedHTML);
    } catch (error) {
      alert("Error optimizing HTML.");
    }
  };

  return (
    <div className="editor-container">
      <div className="editor-sidebar">
        <h3>Components</h3>
        <DragItem content="Heading" />
        <DragItem content="Paragraph" />
        <DragItem content="Image Placeholder" />
      </div>
      <div className="editor-workspace">
        <h3>Workspace</h3>
        <DropZone layout={layout} setLayout={setLayout} />
        <button onClick={handleOptimize}>Optimize HTML</button>
      </div>
      <Preview optimizedHTML={optimizedHTML} />
    </div>
  );
};

export default Editor;
