import React from "react";

const DropZone = ({ layout, setLayout }) => {
  const handleDrop = (e) => {
    e.preventDefault();
    const content = e.dataTransfer.getData("text/plain");
    setLayout([...layout, { content }]);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  return (
    <div
      className="drop-zone"
      onDrop={handleDrop}
      onDragOver={handleDragOver}
    >
      {layout.length === 0 ? (
        <p>Drag items here</p>
      ) : (
        layout.map((item, index) => (
          <div key={index} className="dropped-item">
            {item.content}
          </div>
        ))
      )}
    </div>
  );
};

export default DropZone;
