import React from "react";

const Preview = ({ optimizedHTML }) => {
  return (
    <div className="preview">
      <h3>Optimized HTML Preview</h3>
      {optimizedHTML ? (
        <iframe
          title="Optimized Preview"
          srcDoc={optimizedHTML}
          style={{ width: "100%", height: "300px", border: "1px solid #ccc" }}
        />
      ) : (
        <p>No optimized HTML to display.</p>
      )}
    </div>
  );
};

export default Preview;
