const API_BASE_URL = "http://localhost:3001";

export const optimizeHTML = async (html) => {
  try {
    const response = await fetch(`${API_BASE_URL}/optimize-html`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ html }),
    });

    if (!response.ok) {
      throw new Error("Failed to fetch optimized HTML.");
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error(error);
    throw error;
  }
};
